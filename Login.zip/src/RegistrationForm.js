import React, { Component } from 'react';
import { Icon, Button } from 'semantic-ui-react'
import Modal from './modal';
import './RegistrationForm.css';

class RegistrationForm extends Component {
  constructor(props){
    super(props); 
   this.state = {
      username: '',
      email: '',
      contactNo: '',
      otherContactNo: '',
      password: '',
      password2: '',
      valid: {
        contactNo: true,
        otherContactNo: true,
        username: true,
        password: true,
        password2: true,
        email: true,
      },
      touched: {
        contactNo: false,
        otherContactNo: false,
        username: false,
        password: false,
        password2: false,
        email: false
      },
      modalisOpen: false,
      isChecked: false,
      counter:0
    };

    this.rexExpMap = {
      contactNo: /^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/,
      otherContactNo: /^([0|\+[0-9]{1,5})?([7-9][0-9]{9})$/,
      username: /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/,
      password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/,
      password2: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,10}$/,
      email: /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:[A-Z]{2}|com|org)/,
    
    }
  
    this.handleChange = this.handleChange.bind(this);
    this.checkData = this.checkData.bind(this);
    this.toggleModal = this.toggleModal.bind(this);
    this.checkOnSubmit = this.checkOnSubmit.bind(this);
  }

  handleChange = (e, name) => {
    if(name=='checkbox'){
      this.setState(prevState => ({
        isChecked: !prevState.isChecked
    }));
    }
    else{
        this.setState({[e.target.name]: e.target.value}, () => {
        this.checkData(this.rexExpMap[name], this.state[name], this.state.valid[name], name)
      });
    }
  }
  checkData(regExp, stateName, stateValid, name){
    this.setState({
      touched: { ...this.state.touched, [name]: true }
    });
   if(regExp.test(stateName) && 
    (name=='password2'? this.state.password == this.state.password2 : true) &&
    (name=='otherContactNo'? this.state.contactNo != this.state.otherContactNo : true)
    ) {
      this.setState({
        valid: { ...this.state.valid, [name]: true }
      });
    } else {
      this.setState({
        valid: { ...this.state.valid, [name]: false }
      });
    }
  }
  validate(contactNo, otherContactNo, username, password, password2, email) {  
    return {
      contactNo: contactNo.length === 0,
      otherContactNo: otherContactNo.length === 0,
      username: username.length === 0,
      password: password.length === 0,
      password2: password2.length === 0,
      email: email.length === 0
    };
  }
  requiredStyle(name) {
    const show = (this.state[name] === "" || !this.state.valid[name]) && this.state.touched[name];
    return {display: show ? 'block' : 'none'}
  }
  errorMessages(name) {
    const requiredStr = 'This field is required.';
    const invalidStr = 'Enter valid '+ name +'.';
    return !this.state.valid[name] && this.state[name] !== "" ? invalidStr : requiredStr
  }
  checkOnSubmit() {
    const {contactNo, otherContactNo, username, password, email, isChecked } = this.state;    
    const formFilled = !(contactNo === '' || otherContactNo === '' || username === '' || password === '' || email === '');
    const formInvalid = Object.keys(this.state.valid).some(x => !this.state.valid[x]);
    const formHasErrors = !formFilled || formInvalid || !isChecked;

    if (!formHasErrors) {
      this.toggleModal();
    }
    this.setState({
      touched: {
        contactNo: true,
        otherContactNo: true,
        username: true,
        password: true,
        password2: true,
        email: true,
      },
    });
  }
  toggleModal(){
    this.setState(prevState => ({
      modalisOpen: !prevState.modalisOpen
    }));
  }
  
  render() {
    const errors = this.validate(this.state.contactNo, this.state.otherContactNo, this.state.username, this.state.password, this.state.password2, this.state.email);
    const shouldMarkError = (field) => {
      const hasError = errors[field];
      const shouldShow = this.state.touched[field];
      return hasError ? shouldShow : false;
    }
    const helpMessage = (name) =>{
      return {display: shouldMarkError(name) ? 'none' : 'block'}
    }
    
    return (
      <div className="container">
        <div className="register-form" >
          <div className="title">Create Your Free Account</div>
          <div className="form">
            
            <div>
              <label>
                Name
                <input
                  type="text"
                  value={this.state.username}
                  name="username"
                  className={shouldMarkError("username") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "username")} />
              </label>
              <span className="required-field" style={this.requiredStyle('username')}>{this.errorMessages('username')}</span>
            </div>

            <div>
              <label>
                Email
                <input
                  type="text"
                  name="email"
                  value={this.state.email}
                  className={shouldMarkError("email") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "email")} />
              </label>
              <span className="note" style={helpMessage('email')}>An activatoin link will be sent to this email</span>
              <span className="required-field" style={this.requiredStyle('email')}>{this.errorMessages('email')}</span>
            </div>
          
            <div>
              <label>
                Phone
                <input
                  type="text"
                  value={this.state.contactNo}
                  name="contactNo" id="contactNo"
                  className={shouldMarkError("contactNo") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "contactNo")} />
              </label>
              <span className="required-field" style={this.requiredStyle('contactNo')}>{this.errorMessages('contactNo')}</span>
            </div>

            <div>
              <label>
                Other Phone No.
                <input
                  type="text" 
                  value={this.state.otherContactNo} 
                  name="otherContactNo" id="otherContactNo"
                  className={shouldMarkError("otherContactNo") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "otherContactNo")} />
              </label>
              <span className="required-field" style={this.requiredStyle('otherContactNo')}>{this.errorMessages('otherContactNo')}</span>
            </div>

            <div>
              <label>
                Password
                <input
                  type="password"
                  value={this.state.password}
                  name="password"
                  className={shouldMarkError("password") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "password")} />
              </label>
              <span className="note" style={helpMessage('password')}>Min. 8 and max 10 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number and 1 special character</span>
              <span className="required-field" style={this.requiredStyle('password')}>{this.errorMessages('password')}</span>
            </div>

            <div>
              <label>
                Confirm Password
                <input
                  type="password"
                  value={this.state.password2}
                  name="password2"
                  className={shouldMarkError("password2") ? "error" : ""}
                  onChange={(e) => this.handleChange(e, "password2")} />
              </label>
              <span className="note" style={helpMessage('password2')}>Min. 8 and max 10 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number and 1 special character</span>
              <span className="required-field" style={this.requiredStyle('password2')}>{this.errorMessages('password2')}</span>
            </div>


            <div className="sb-text">
              <input className="sb-box" 
                type="checkbox" 
                name="terms" 
                checked={this.state.isChecked} 
                onChange={(e) => this.handleChange(e, "checkbox")}  
              />
            
            &nbsp;&nbsp;By clicking checkbox, I agree  that I have read and accepted the&nbsp;
              <a href='TermsandConditions'>Terms and Conditions.</a>
            </div>            
            <button className="sb-btn" type="button" onClick={this.checkOnSubmit}>SUBMIT</button>            
          </div>
        </div>
        {this.state.modalisOpen? 
          <Modal
            text='Your Data'
            {...this.state}
            closeModal={this.toggleModal}
          />
          : null
        }
      </div>
    );
  } 
  
}


export default RegistrationForm;