import React, { Component } from 'react';

class Modal extends Component {
  render() {
    return (
      <div className='modal'>
        <div className='modal-content'>
          <div className="modal-title">{this.props.text}</div>
          <div>
            <div className="modal-label">
              <div>Name: </div>
              <div className="modal-input-value">{this.props.username}</div>
            </div>
            <div className="modal-label">
              <div>Contact No: </div>
              <div className="modal-input-value">{this.props.contactNo}</div>
            </div>
            <div className="modal-label">
              <div>Other Contact No: </div>
              <div className="modal-input-value">{this.props.otherContactNo}</div>
            </div>
            {/* <div className="modal-label">
              <div>Passwort: </div>
              <div className="modal-input-value">{this.props.password}</div>
            </div> */}
            <div className="modal-label">
              <div>Email: </div>
              <div className="modal-input-value">{this.props.email}</div>
            </div>
          </div>
          <button className="modal-btn" onClick={this.props.closeModal}>Close</button>
        </div>
      </div>
    );
  }
};
 
export default Modal;
  