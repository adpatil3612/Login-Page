# react_registration_form
Sample Registration form with all validations on each input field.

Run npm start to run application on localhost:3000
